import { attendanceService } from "@/features/attendance/services/attendanceService";
import type { AttendanceRecord, TeamCalendarResponse } from "@/features/attendance/types";
import { useCallback, useState } from "react";



export const useCalendar = () => {
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [teamAttendanceReport, setTeamAttendanceReport] = useState<AttendanceRecord[]>([]);
  const [pagination, setPagination] = useState({ totalPages: 0, totalElements: 0, currentPage: 0 });
  const [attendanceReport, setAttendanceReport] = useState<AttendanceRecord[]>([]);

  const [teamCalendar, setTeamCalendar] =
    useState<TeamCalendarResponse>({});

  const [employeeCalendar, setEmployeeCalendar] =
    useState<TeamCalendarResponse>({});

  const [attendance, setAttendance] = useState<Record<string, AttendanceRecord>>({});
  /*
  ========================
  TEAM LEAVE CALENDAR
  ========================
  */
  const fetchTeamSchedule = useCallback(
    async (employeeId: string) => {
      try {
        setLoading(true);

        const data =
          await attendanceService.getTeamCalendar(employeeId);

        setTeamCalendar(data || {});

        return data;
      } catch (err) {
        console.error("team calendar error", err);
        setError("Failed to fetch team calendar");
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  /*
  ========================
  MY LEAVE CALENDAR
  ========================
  */
  const fetchEmployeeCalendar = useCallback(
    async (employeeId: string) => {
      try {
        setLoading(true);

        const data =
          await attendanceService.getEmployeeCalendar(employeeId);

        setEmployeeCalendar(data || {});
      } catch (err: any) {
        console.error("employee calendar error", err);
        setError(err.message || "Failed to fetch employee calendar");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  /*
  ========================
  ATTENDANCE CALENDAR
  ========================
  */
  // In your component

  const fetchAttendanceCalendar = useCallback(
    async (employeeId: string, year: number, month: number) => {
      try {
        setLoading(true);
        setError(null);

        const data: AttendanceRecord[] = await attendanceService.getAttendance(employeeId, year, month);

        // Transform Array -> Object { "2026-04-11": Record }
        const attendanceMap = data.reduce((acc, record) => {
          acc[record.date] = record;
          return acc;
        }, {} as Record<string, AttendanceRecord>);

        setAttendance(attendanceMap);
      } catch (err) {
        console.error("Attendance fetch error:", err);
        setError("Failed to fetch attendance records.");
      } finally {
        setLoading(false);
      }
    },
    []
  );
  const fetchTeamAttendanceReport = useCallback(
    async (reportingId: string, filters: { fromDate?: string; toDate?: string; status?: string; page?: number; size?: number }) => {
      try {
        setLoading(true);
        setError(null);

        const data = await attendanceService.getTeamAttendanceReport(reportingId, filters);

        setTeamAttendanceReport(data.content || []);
        setPagination({
          totalPages: data.totalPages,
          totalElements: data.totalElements,
          currentPage: data.number
        });

        return data;
      } catch (err: any) {
        console.error("Team attendance report error", err);
        setError(err.message || "Failed to fetch team attendance report");
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );

  const fetchEmployeeAttendanceReport = useCallback(
    async (empId: string, filters: { fromDate?: string; toDate?: string; page?: number; size?: number }) => {
      try {
        setLoading(true);
        setError(null);

        const data = await attendanceService.getEmployeeAttendanceByRange(empId, filters);

        setAttendanceReport(data.content || []);
        setPagination({
          totalPages: data.totalPages,
          totalElements: data.totalElements,
          currentPage: filters.page || 0,
        });

        return data;
      } catch (err: any) {
        console.error("Employee report error:", err);
        setError(err.message || "Failed to fetch employee attendance report");
        return null;
      } finally {
        setLoading(false);
      }
    },
    []
  );
  const downloadAttendanceExcel = useCallback(
    async (empId: string, filters: { fromDate?: string; toDate?: string }) => {
      try {
        setLoading(true); // Optional: show spinner while the server generates the file
        setError(null);

        // This calls the API service we created in the previous step
        await attendanceService.downloadAttendanceExcel(empId, filters);

      } catch (err: any) {
        console.error("Excel download error:", err);
        setError(err.message || "Failed to download Excel report");
      } finally {
        setLoading(false);
      }
    },
    []
  );

  /*
  ========================
  EXPORT API
  ========================
  */
  return {
    loading,
    error,

    teamCalendar,
    employeeCalendar,
    attendance,
    fetchTeamSchedule,
    fetchEmployeeCalendar,
    fetchAttendanceCalendar,
    teamAttendanceReport,
    pagination,
    fetchTeamAttendanceReport,
    attendanceReport,
    fetchEmployeeAttendanceReport,
    downloadAttendanceExcel
  };
};